package com.capgemini.service;

import java.util.ArrayList;

import com.capgemini.bean.BookingBean;
import com.capgemini.bean.BusBean;
import com.capgemini.dao.BusDaoImpl;
import com.capgemini.dao.IBusDao;
import com.capgemini.exception.BookingException;

public class BusServiceImpl implements IBusService {
	IBusDao ibus=new BusDaoImpl();

	@Override
	public ArrayList<BusBean> retrieveBusDetails() throws BookingException {
		// TODO Auto-generated method stub
		
		return ibus.retrieveBusDetails();
	}

	@Override
	public int bookTicket(BookingBean bookingBean) throws BookingException {
		// TODO Auto-generated method stub
		return ibus.bookTicket(bookingBean);
	}

	@Override
	public boolean updatenoOfSeats(int noOfSeat) throws BookingException {
		// TODO Auto-generated method stub
		return ibus.updatenoOfSeats(noOfSeat);
	}
	

}
