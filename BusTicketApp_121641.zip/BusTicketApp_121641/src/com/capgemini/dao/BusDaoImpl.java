package com.capgemini.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.bean.BookingBean;
import com.capgemini.bean.BusBean;
import com.capgemini.exception.BookingException;
import com.capgemini.util.JdbcUtil;
import com.cg.mobilesystem.exception.MobileException;


public class BusDaoImpl implements IBusDao {
	
	Connection con;
	PreparedStatement pst;
	IBusDao upd=new BusDaoImpl();
	

	@Override
	public ArrayList<BusBean> retrieveBusDetails() throws BookingException {
		
		// TODO Auto-generated method stub
		con=JdbcUtil.getConnection();
		String query="SELECT * from BusDetails";
		List<BusBean>mList=new ArrayList<BusBean>();
		
		try {
			pst=con.prepareStatement(query);
			
			ResultSet rs=pst.executeQuery();
			while(rs.next()){
				int m_id=rs.getInt(1);
				String m_type=rs.getString(2);
				
				String m_fstop=rs.getString(3);
				String m_tstop=rs.getString(4);
				int m_seats=rs.getInt(5);
				int m_fare=rs.getInt(6);
				long time=rs.getLong(7);
				Date DateOfJourney=new Date(Time);
				BusBean m=new BusBean();
				m.setBusid(m_id);
				m.setBusType(m_type);
				m.setDateOfJourney(m_date);
				m.setFromStop(m_fstop);
				m.setToStop(m_tstop);
				m.setAvailableSeats(m_seats);
				m.setFare(m_fare);
				mList.add(m);
				}
			
			
				
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try{
				con.close();
			}catch (SQLException e){
				e.printStackTrace();
				throw new BookingException("Data not found");
			}
		}
		
		return mList;
	}

	@Override
	public int bookTicket(BookingBean bookingBean) throws BookingException {
		// TODO Auto-generated method stub
		int rec=0;
		BookingBean b=new BookingBean();
		
		con=JdbcUtil.getConnection();
		String query="Insert into BookingDetails values(sequence_id.NEXTVAL,?,?,?,?)";
		
	
		try {
			con = JdbcUtil.getConnection();
			pst=con.prepareStatement(query);
			pst.setInt(1,b.getBookingId());
			pst.setString(2, b.getCustId());
			pst.setInt(3, b.getBusId());
			pst.setInt(4, b.getNoOfSeat());
			rec=pst.executeUpdate();
			if(rec>0)
			{
				upd.updatenoOfSeats(b.getNoOfSeat());
				
			}
			
			
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try{
				con.close();
			}catch (SQLException e){
				e.printStackTrace();
				throw new BookingException("Data not inserted");
			}
		}
		
		return 0;
	}

	@Override
	public boolean updatenoOfSeats(int noOfSeat) throws BookingException {
		// TODO Auto-generated method stub
		con=JdbcUtil.getConnection();
		int rec=0;
		String query="UPDATE BusDetails SET availableSeats=availableSeats-? WHERE busId=?";
		
		
		try {
			pst=con.prepareStatement(query);
			pst.setInt(1, noOfSeat);
			rec=pst.executeUpdate();
			if(rec>0)
				return true;
			
			
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try{
				con.close();
			}catch (SQLException e){
				e.printStackTrace();
				throw new BookingException("data is not updated");
		}
		return false;
	}
	
	
	
	}
}
