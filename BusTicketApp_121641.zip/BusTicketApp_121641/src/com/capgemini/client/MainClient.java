package com.capgemini.client;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;

import com.capgemini.bean.BookingBean;
import com.capgemini.exception.BookingException;
import com.capgemini.service.BusServiceImpl;
import com.capgemini.service.IBusService;
import com.cg.mobilesystem.exception.MobileException;



public class MainClient {
	final static Logger myLogger=Logger.getLogger(MainClient.class);
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		IBusService btb=new BusServiceImpl();
		BookingBean bookingBean=new BookingBean();
		int choice=0;
		do{
			 printDetail();
		Scanner scr=new Scanner(System.in);
		choice=scr.nextInt();
		switch(choice){
		case 1://retrieveData
			try{
			System.out.println(btb.retrieveBusDetails());
			myLogger.info("data found");
			} catch (BookingException e1) {
				 myLogger.error("data not found");
			     e1.printStackTrace();
				break;
			}
		case 2://bookticket
			 Scanner sc=new Scanner(System.in);
			 BookingBean b=new BookingBean();
			 int count=0;
			 System.out.println("Enter customerId : ");
			 String cid=sc.next();
			 Pattern custId=Pattern.compile("^[A-Z]{1}[0-9]{0,5}$");
			 Matcher cid1=custId.matcher(cid);
			 if(cid1.matches()){
				 b.setCustId(cid);
				count++; 
			 }
			 
			 System.out.println("Enter bus-id : ");
			 int bid=sc.nextInt();
			 Pattern busId=Pattern.compile("^(1|2|3){1}$");
			 Matcher bid1=busId.matcher(bid);
			 if(bid1.matches()){
				b.setBusId(bid);
				count++;
				
			 }
			 int noOfSeat=0;
			 System.out.println("Enter no. of seats:");
			 int ns=sc.nextInt();
			 bookingBean.setNoOfSeat(noOfSeat);
			 
			  if(ns>0 && ns< updatenoOfSeats(b.getNoOfSeat()){
				  
				 System.out.println("Thank you. your booking id is"+b);
				 count++;
			 }else
			 {
				 System.out.println("Sorry No Seats Available");
			 }
			
			 
			 if(count==3)
			 {
				int var;
				try{
				 var=btb.bookTicket(b);
				   System.out.println(var);
	 
			 }catch (BookingException e){
				 
			 
			     	e.printStackTrace();
		}
			 }else{
				 System.out.println("Enter details again");
			 }
			 break;
			 
			 case 3://exit
				 
				 break;
				 
		}
		}
		while (choice!=3);
		
	
			 
		
	}
		public static void printDetail(){
			System.out.println("-----------------------------------");
			System.out.println("1. Display Bus Details ");
			System.out.println("2. Book Ticket");
			System.out.println("3. Exit");
			System.out.println("----------------------------------");
		}
}
