package com.capgemini.junittest;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.capgemini.dao.BusDaoImpl;
import com.capgemini.dao.IBusDao;

public class BookTicketDetailTest {
	busDao=
	IBusDao ibus=new BusDaoImpl();
	@Before
	public void setUp() throws Exception {
	busDao=new busDaoImpl;
	bookingBean=new BookingBean();
	
	
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
