package com.capgemini.service;

import java.util.ArrayList;

import com.capgemini.bean.BookingBean;
import com.capgemini.bean.BusBean;
import com.capgemini.exception.BookingException;

public interface BusService {

	public ArrayList<BusBean> retrieveBusDetails()throws BookingException;
	public int bookTicket(BookingBean bookingBean) throws BookingException; 
	public int generateBookingId()throws BookingException;
	public int checkAvailabeSeats(int busId)throws BookingException;
	/*int updateSeats(int busId, int noOfSeats) throws BookingException;*/
}
