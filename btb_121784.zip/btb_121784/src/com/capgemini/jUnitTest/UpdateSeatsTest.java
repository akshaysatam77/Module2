package com.capgemini.jUnitTest;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.Test;

import com.capgemini.bean.BookingBean;
import com.capgemini.bean.BusBean;
import com.capgemini.dao.BusDao;
import com.capgemini.dao.BusDaoImpl;
import com.capgemini.exception.BookingException;

public class UpdateSeatsTest {
	BusDao busDao;
	BusBean busBean;
	BookingBean bookingBean;
	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
		busDao=new BusDaoImpl();
		busBean=new BusBean();
		bookingBean=new BookingBean();
	}

	@After
	public void tearDown() throws Exception {
		busDao=null;
		busBean=null;
		bookingBean=null;
	}

	@Test
	public void test() throws BookingException {
		assertNotNull(busDao.updateSeats(bookingBean.getBusId(), bookingBean.getNoOfSeat()));
	}

}
