package com.capgemini.dao;

import java.util.ArrayList;

import com.capgemini.bean.BookingBean;
import com.capgemini.bean.BusBean;
import com.capgemini.exception.BookingException;

public interface BusDao {

	ArrayList<BusBean> retrieveBusDetails()throws BookingException;
	int bookTicket(BookingBean bookingBean)throws BookingException;
	
	int checkAvailabeSeats(int busId)throws BookingException;
	int generateBookingId()throws BookingException;
	int updateSeats(int busId, int noOfSeats) throws BookingException;
}
