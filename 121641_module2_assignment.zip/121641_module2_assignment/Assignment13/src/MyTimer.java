
public class MyTimer {
	public static void main(String[] args) {
		Timer t=new Timer();
		Thread d=new Thread(t);
		d.start();

	}

}
