
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class CopyDataThread extends Thread{
	@Override
	public void run(){
		File in =new File("source.txt");
		File out =new File("target.txt");
		
		try {
			FileReader infile=new FileReader(in);
			FileWriter outfile=new FileWriter(out);
			int c;
			int count=1;
			while((c=infile.read())!=-1)
			{
				outfile.write(c);
				if(count>=10)
				{
					System.out.println("10 characters are copied");
					try {
						sleep(10000);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					count=1;
					
				}
				else {
					count++;
				}
				
			}
			infile.close();
			outfile.close();
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
	}

}
