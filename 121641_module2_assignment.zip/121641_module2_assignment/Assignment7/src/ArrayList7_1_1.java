import java.util.ArrayList;
import java.util.Collections;


public class ArrayList7_1_1 {
	
	public static void main(String[] args){
	
	ArrayList<String> aList=new ArrayList<>();
	
	//System.out.println("Enter the product names:");

	aList.add("soap");
	aList.add("toothpaste");
	aList.add("souce");
	aList.add("TV");
	aList.add("PC");
	
	Collections.sort(aList); 
	System.out.println("Array after sorting");
	
	for(String s:aList){
	     System.out.println(s);
	}
}
	}