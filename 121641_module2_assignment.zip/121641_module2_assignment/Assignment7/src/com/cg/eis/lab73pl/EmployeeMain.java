package com.cg.eis.lab73pl;

import com.cg.eis.lab73.bean.Employee;
import com.cg.eis.lab73.service.EmployeeServiceImpl;
import com.cg.eis.lab73.service.IEmployeeService;

public class EmployeeMain {

	public static void main(String[] args) {
		Employee emp1=new Employee(101,"Prathamesh",50000,"Manager");
		Employee emp2=new Employee(102,"Akshay",20000,"Programmer");
		Employee emp3=new Employee(103,"Aditya",19000,"System Analyst");
		Employee emp4=new Employee(104,"Lobo",5000,"Clerk");
		
		IEmployeeService es=new EmployeeServiceImpl();
		
		
		emp1.setInsuranceScheme(es.calcScheme(emp1.getSalary(), emp1.getDesignation()));
		emp2.setInsuranceScheme(es.calcScheme(emp2.getSalary(), emp2.getDesignation()));
		emp3.setInsuranceScheme(es.calcScheme(emp3.getSalary(), emp3.getDesignation()));
		emp4.setInsuranceScheme(es.calcScheme(emp4.getSalary(), emp4.getDesignation()));
		
		
		es.addEmployee("Prathamesh", emp1);
		es.addEmployee("Akshay", emp2);
		es.addEmployee("Aditya", emp3);
		es.addEmployee("Lobo", emp4);
		
		es.deleteEmployee("Lobo");
		es.sortAndDisplay();
	

	}

}
