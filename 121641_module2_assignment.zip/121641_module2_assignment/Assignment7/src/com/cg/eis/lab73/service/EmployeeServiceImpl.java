package com.cg.eis.lab73.service;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

import com.cg.eis.lab73.bean.Employee;




public class EmployeeServiceImpl implements IEmployeeService {
	Employee emp;
	HashMap<String,Employee> list = new HashMap<String,Employee>();
	@Override
	public void addEmployee(String name, Employee emp) {
		// TODO Auto-generated method stub
		list.put(name,emp);
		
		
	}
	@Override
	public void deleteEmployee(String name) {
		// TODO Auto-generated method stub
		list.remove(name);
		
		
	}
	@Override
	public String calcScheme(double salary , String designation) {
		
		if((salary>5000 && salary<20000) && 
				(designation.equals("System Associate"))){
			return "Scheme C";
			
		}
		else
			if((salary>=20000 && salary<40000) && 
					(designation.equals("Programmer"))){
				return "Scheme B";
				
			}
			else
				if((salary>=40000) && 
						(designation.equals("Manager"))){
					return "Scheme A";
				}
				else
					if((salary<=5000) && 
							(designation.equals("Clerk"))){
						return "No Scheme";
					}
	return "Faulty Change";	
		
		
	}
	@Override
	public void sortAndDisplay() {
		Set tempset=list.entrySet();
		Iterator itr=tempset.iterator();
		while(itr.hasNext()){
			Map.Entry mapEntry=(Map.Entry)itr.next();
			System.out.println(mapEntry.getKey()+":"+mapEntry.getValue());
		
	}
	
	
 
	}
}
