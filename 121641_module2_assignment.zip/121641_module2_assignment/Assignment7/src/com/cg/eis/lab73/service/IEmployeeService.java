package com.cg.eis.lab73.service;

import com.cg.eis.lab73.bean.Employee;

public interface IEmployeeService {
	public void addEmployee(String name,Employee emp);
	public void deleteEmployee(String name);
	public String calcScheme(double data1,String data2);
	public void sortAndDisplay();
	

}
