import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;
public class ArrayList7_2 {
	
	public static void main(String[]args){
		Scanner sc=new Scanner(System.in);
	List <String>list=new ArrayList<>();
	String s1=null;

	System.out.println("Enter the number of products");
	int num=sc.nextInt();
	System.out.println("Enter the products' name");
	for(int i=0;i<=num;i++){
		s1=sc.nextLine();
		list.add(s1);
	}
	
	
	Collections.sort(list);
	System.out.println("Sorted Products");
	for(String s:list){
		System.out.println(s);
		
	}
}

}
