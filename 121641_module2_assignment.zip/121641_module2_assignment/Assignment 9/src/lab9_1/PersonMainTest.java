package lab9_1;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class PersonMainTest {
Person p;
	@Before
	public void setUp() throws Exception {
		
		p=new Person();
		
	}

	@After
	public void tearDown() throws Exception {
		
		
	}

	@Test
	public void testgetFirstName() {
		
		Person p=new Person("Akshay", "Satam", 'M');
		assertEquals(p.getFirstName(),"Akshay");
	   
	}

	@Test
	public void testgetLastName(){
		Person p=new Person("Akshay", "Satam", 'M');
		assertEquals(p.getLastName(),"Satam");
		
	}
	
	
	@Test
	public void testgetGender(){
		Person p=new Person("Akshay", "Satam", 'M');
		assertEquals(p.getGender(),'M');
	}		
	
	
	
}
