package com.cg.mobile.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


import org.apache.log4j.Logger;

import com.cg.mobile.dto.Purchase;
import com.cg.mobile.exceptions.MobileException;
import com.cg.mobile.util.JdbcUtil;

public class PurchaseDaoImpl implements IPurchaseDao {
	Connection con;
	PreparedStatement pst;
	PreparedStatement sequence;
	PreparedStatement mobile;
	private static final Logger mylogger = Logger.getLogger(JdbcUtil.class);

	public boolean Insert(Purchase p) throws MobileException {
		IMobileDao upd = new MobileDaoImpl();
		try {
			con = JdbcUtil.getConnection();
		} catch (MobileException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		String query = "INSERT INTO PURCHASEDETAILS VALUES(PURCHASEID.NEXTVAL,?,?,?,sysdate,?)";
		String select = "SELECT MOBILEID FROM MOBILES";
		int count = 0;
		try {
			pst = con.prepareStatement(query);
			mobile = con.prepareStatement(select);
			ResultSet rs = mobile.executeQuery();
			int s4 = p.getMobileid();
			while (rs.next()) {

				if (s4 == rs.getInt(1)) {
					count++;
				}
			}
			pst.setString(1, p.getCname());
			pst.setString(2, p.getMailid());
			pst.setString(3, p.getPhoneno());

			if (count > 0) {
				pst.setInt(4, s4);
			} else {
				throw new MobileException("There is no such Mobile Id");
			}

			
			int a = pst.executeUpdate();

			if (a == 1) {
				try {
					mylogger.info("Mobile Purchased Successfully");
					upd.updateQty(s4, p.getQuantity());
				} catch (MobileException e) {
					
					mylogger.error("Mobile Purchase Unsuccessfull");
					e.printStackTrace();
				}
				return true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return false;
	}
	

}
