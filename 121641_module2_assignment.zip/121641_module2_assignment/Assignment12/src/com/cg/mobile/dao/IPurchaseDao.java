package com.cg.mobile.dao;

import com.cg.mobile.dto.Purchase;
import com.cg.mobile.exceptions.MobileException;

public interface IPurchaseDao {
public boolean Insert(Purchase p) throws MobileException;
}
