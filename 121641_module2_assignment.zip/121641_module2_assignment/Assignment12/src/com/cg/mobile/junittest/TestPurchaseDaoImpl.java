package com.cg.mobile.junittest;

import static org.junit.Assert.*;

import java.util.Date;

import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.mobile.dao.IPurchaseDao;
import com.cg.mobile.dao.PurchaseDaoImpl;
import com.cg.mobile.dto.Purchase;
import com.cg.mobile.exceptions.MobileException;

public class TestPurchaseDaoImpl {

IPurchaseDao ipd;
Purchase p;

	@Before
	public void setUp() throws Exception {
		ipd=new PurchaseDaoImpl();
		p=new Purchase("Raunak","asda@dasd.com","9920798102",1003,2);
	}

	@Test
	public void test() {
		try {
			assertTrue(ipd.Insert(p));
		} catch (MobileException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@After
	public void tearDown() throws Exception{
		ipd=null;
		p=null;
	}
}
