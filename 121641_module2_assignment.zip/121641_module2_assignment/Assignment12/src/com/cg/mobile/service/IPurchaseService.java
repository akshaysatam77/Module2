package com.cg.mobile.service;

import com.cg.mobile.dto.Purchase;
import com.cg.mobile.exceptions.MobileException;

public interface IPurchaseService {
	public boolean InsertInto(Purchase p) throws MobileException;

}
