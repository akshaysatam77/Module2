package Lab10_1;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Properties;

public class ReadDemoA {

	public static void writeProperties(){
		Properties prop=new Properties();
		prop.setProperty("oracle.driver","oracle.jdbc.driver.OracleDriver");
		prop.setProperty("oracle.url", "jdbc:oracle:thin:@localhost:1521:xe");
		prop.setProperty("oracle.uname", "pkasbe");
		prop.setProperty("oracle.password","Pratsk");
		OutputStream output=null;
		try{
			output=new FileOutputStream("PersonProps.properties");
			prop.store(output, null);
			prop.list(System.out);
		}catch(IOException io){
			io.printStackTrace();
		}finally{
			if(output!=null){
				try{
					output.close();
				}catch(IOException e){
					e.printStackTrace();
				}
			}
		}
	}
	
	public static void main(String[] args) {
		
writeProperties();
	}

}
