package com.cg.empmgmt.lab10_2.dao;

import java.util.ArrayList;

import com.cg.empmgmt.lab10_2.dto.Employee1;
import com.cg.empmgmt.lab10_2.exception.EmployeeException;

public interface IemployeeDao {


	public boolean addEmployee(int id,String name,double salary,String designation,String insuranceScheme)throws EmployeeException;
	public boolean deleteEmployee(String name)throws EmployeeException;
	public String calcScheme(double data1,String data2)throws EmployeeException;
	ArrayList<Employee1> retrieveDetails() throws EmployeeException;
	
	
}
