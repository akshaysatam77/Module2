package com.cg.empmgmt.lab10_2.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;






import com.cg.empmgmt.lab10_2.dto.Employee1;
import com.cg.empmgmt.lab10_2.exception.EmployeeException;
import com.cg.empmgmt.lab10_2.util.JdbcUtil;



public class EmployeeDaoImpl implements IemployeeDao{
	public String insuranceScheme;
	
Employee1 emp;
	Connection con=null;
	PreparedStatement pst=null;
	@Override
	public boolean addEmployee(int id,String name,double salary,String designation,String insuranceScheme)throws EmployeeException {
	con=JdbcUtil.getConnection();
	String query="INSERT INTO EMPLOYEE1 VALUES(?,?,?,?,?)";
	int rec=0;
	try {
		pst=con.prepareStatement(query);
		pst.setInt(1,id);
		pst.setString(2, name);
		pst.setDouble(3, salary);
		pst.setString(4, designation);
		pst.setString(5, insuranceScheme);
		rec=pst.executeUpdate();
		if(rec>0){
			return true;
		}
		} catch (SQLException e) {
		e.printStackTrace();
		throw new EmployeeException("Employee is not added");
	}finally{
		try{
			con.close();
		}catch (SQLException e) {
			e.printStackTrace();
		}
	}
	return false;
	}

	@Override
	public boolean deleteEmployee(String name) throws EmployeeException{
		con=JdbcUtil.getConnection();                      
		int rec=0;
		String query="DELETE FROM EMPLOYEE1 WHERE NAME=?"; 
		try {
			pst=con.prepareStatement(query);
		pst.setString(1,name);
		rec=pst.executeUpdate();
		if(rec>0){
			return true;
		}
		}catch (SQLException e) {
			e.printStackTrace();
			throw new EmployeeException("Employee record not Deleted");
		}finally{
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return false;
	}

	@Override
	public String calcScheme(double salary,String designation) throws EmployeeException{
		if((salary>5000 && salary<20000) && 
				(designation.equals("System Associate"))){
			
			insuranceScheme= "Scheme C";
			
		}
		else
			if((salary>=20000 && salary<40000) && 
					(designation.equals("Programmer"))){
		
				insuranceScheme= "Scheme B";
				
			}
			else
				if((salary>=40000) && 
						(designation.equals("Manager"))){
					insuranceScheme="Scheme A";
					
				}
				else
					if((salary<=5000) && 
							(designation.equals("Clerk"))){
						
						insuranceScheme= "No scheme";
					}
	
		return insuranceScheme;
	}

	@Override
	public ArrayList<Employee1> retrieveDetails() throws EmployeeException {
		con=JdbcUtil.getConnection();                      
		String query="SELECT * FROM Employee1";              
		ArrayList<Employee1> mList=new ArrayList<Employee1>();
		try {
			pst=con.prepareStatement(query);
			ResultSet rs=pst.executeQuery();
			while(rs.next()){
				int e_id=rs.getInt(1); 
				String name=rs.getString(2);  
				Double salary=rs.getDouble(3);
				String designation=rs.getString(4);
				String insurance=rs.getString(5);
				
							
				Employee1 emp=new Employee1();
				emp.setId(e_id);
				emp.setName(name);
				emp.setSalary(salary);
				emp.setDesignation(designation);
				emp.setInsuranceScheme(insurance);
				
				mList.add(emp);
				
			}
		}catch(SQLException e){
			System.out.println(e);
			throw new EmployeeException("No data available in the database");
		}finally{
			try{
			    con.close();
				pst.close();
			}catch(SQLException e){
				e.printStackTrace();
			}
			
		}
		return mList;
	}

}
