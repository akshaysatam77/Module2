package com.cg.empmgmt.lab10_2.service;

import java.util.ArrayList;

import com.cg.empmgmt.lab10_2.dto.Employee1;
import com.cg.empmgmt.lab10_2.exception.EmployeeException;



public interface IemployeeService {
	public boolean addEmployeeDetails(int id,String name,double salary,String designation,String insuranceScheme)throws EmployeeException;
	public boolean deleteEmployeeDetails(String name)throws EmployeeException;
	public String calculateEmployeeScheme(double salary,String designation)throws EmployeeException;
	ArrayList<Employee1> retrieveEmployeeDetails() throws EmployeeException;
}
