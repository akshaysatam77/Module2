package com.cg.empmgmt.lab10_2.ui;


import com.cg.empmgmt.lab10_2.dto.Employee1;
import com.cg.empmgmt.lab10_2.exception.EmployeeException;
import com.cg.empmgmt.lab10_2.service.EmployeeServiceImpl;
import com.cg.empmgmt.lab10_2.service.IemployeeService;

public class EmployeeMain {

	public static void main(String[] args) {
		Employee1 emp1=new Employee1(101,"Prathamesh",50000,"Manager");
		Employee1 emp2=new Employee1(102,"Akshay",20000,"Programmer");
		Employee1 emp3=new Employee1(103,"Aditya",19000,"System Analyst");
		Employee1 emp4=new Employee1(104,"Lobo",5000,"Clerk");
		
		IemployeeService es=new EmployeeServiceImpl();
		
		
			
				try {
					emp1.setInsuranceScheme(es.calculateEmployeeScheme(emp1.salary,emp1.designation));
				
				emp2.setInsuranceScheme(es.calculateEmployeeScheme(emp2.salary,emp2.designation));
				emp3.setInsuranceScheme(es.calculateEmployeeScheme(emp3.salary,emp3.designation));
				emp4.setInsuranceScheme(es.calculateEmployeeScheme(emp4.salary,emp4.designation));
				
			
				es.addEmployeeDetails(emp1.id, emp1.name,emp1.salary,emp1.designation,emp1.insuranceScheme);
				es.addEmployeeDetails(emp2.id, emp2.name,emp2.salary,emp2.designation,emp2.insuranceScheme);
				es.addEmployeeDetails(emp3.id, emp3.name,emp3.salary,emp3.designation,emp3.insuranceScheme);
				es.addEmployeeDetails(emp4.id, emp4.name,emp4.salary,emp4.designation,emp4.insuranceScheme);
		
			
				System.out.println(es.retrieveEmployeeDetails());
				
				System.out.println("After deleting one record");
			
			es.deleteEmployeeDetails("Lobo");
			System.out.println(es.retrieveEmployeeDetails());
				} catch (EmployeeException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			
	}
	}


