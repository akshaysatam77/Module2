package com.cg.eis.service;

import java.util.Scanner;

import com.cg.eis.bean.Employee;
import com.cg.eis.exception.EmployeeException;

public class EmployeeServiceImpl implements IEmployeeService {
    
	Employee emp;
	
	@Override
	public void inputEmployee() {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter id:");
		int id=sc.nextInt();
		System.out.println("Enter Name:");
		String name=sc.next();
		System.out.println("Enter Salary:");
		double salary=sc.nextDouble();
		System.out.println("Enter Designation:");
		String designation=sc.next();
		
		emp=new Employee(id,name,salary,designation);
		
		
	}

	@Override
	public void findInsuranceScheme() {
		double salary=emp.getSalary();
		System.out.println(emp.getSalary());
		
		String designation=emp.getDesignation();
		if((salary>=5000 && salary<20000) && 
				(designation.equals("System Associate"))){
			emp.setInsuranceScheme("Scheme C");
			System.out.println(emp.getInsuranceScheme());
		}
		else
			if((salary>=20000 && salary<40000) && 
					(designation.equals("Programmer"))){
				emp.setInsuranceScheme("Scheme B");
				System.out.println(emp.getInsuranceScheme());
			}
			else
				if((salary>=40000) && 
						(designation.equals("Manager"))){
					emp.setInsuranceScheme("Scheme A");
					System.out.println(emp.getInsuranceScheme());
				}
				else
					if((salary<=5000) && 
							(designation.equals("Clerk"))){
						emp.setInsuranceScheme("No scheme");
						System.out.println(emp.getInsuranceScheme());
					}
					else{
						System.out.println("Invalid");
					}
		
		
		
		
		
	}

	@Override
	public void displayDetails() {
		// TODO Auto-generated method stub
		System.out.println(emp);
	}
	
	
		

}
