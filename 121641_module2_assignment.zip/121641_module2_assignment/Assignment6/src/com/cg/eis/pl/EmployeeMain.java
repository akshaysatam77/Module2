package com.cg.eis.pl;

import com.cg.eis.service.EmployeeServiceImpl;

public class EmployeeMain {
	public static void main(String[] args){
		 EmployeeServiceImpl emp1= new  EmployeeServiceImpl();
		 emp1.inputEmployee();
		 emp1.findInsuranceScheme();
		 emp1.displayDetails();
		 
		
	}

}
