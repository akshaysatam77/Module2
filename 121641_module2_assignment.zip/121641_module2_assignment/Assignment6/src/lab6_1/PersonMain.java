package lab6_1;

import java.util.Scanner;

import javax.naming.NameNotFoundException;

public class PersonMain {

	public static void main(String[] args) throws NameNotFoundException {
		Person p1=new Person();
		Scanner sc=new Scanner(System.in);
		String first="";
		String last="";
		System.out.println("Please Enter First Name");
		first=sc.nextLine();
		p1.setFirstName(first);
		System.out.println("Please Enter Last Name");
		last=sc.nextLine();
		p1.setLastName(last);
		p1.setGender('M');
		System.out.println("First Name:"+p1.getFirstName());
		System.out.println("Last Name:"+p1.getLastName());

		
	
}
	
}


