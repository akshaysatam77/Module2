package lab6_1;

import javax.naming.NameNotFoundException;

public class Person {


	String firstName;
	String lastName;
	char gender;

	public Person() {
		super();
	}
	public Person(String firstName, String lastName, char gender) throws NameNotFoundException{
		super();
		if(firstName.length()!=0)
		{
		this.firstName = firstName;
		}
		else{
			throw new NameNotFoundException("First Name must be Entered");
		}
		if(lastName.length()!=0)
		{
		this.lastName = lastName;
		}
		else
		{
			throw new NameNotFoundException("Last Name must be Entered");
		}
		this.gender = gender;
	}
	
	public String getFirstName() {
		
		return firstName;
	}
	public void setFirstName(String firstName) throws NameNotFoundException {
		if(firstName.length()!=0)
		{
		this.firstName = firstName;
		}
		else{
			throw new NameNotFoundException("First Name must be Entered");
		}
	}
	
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) throws NameNotFoundException {
		if(lastName.length()!=0)
		{
		this.lastName = lastName;
		}
		else
		{
			throw new NameNotFoundException("Last Name must be Entered");
		}
	}
	public char getGender() {
		return gender;
	}
	public void setGender(char gender) {
		this.gender = gender;
	}

}


