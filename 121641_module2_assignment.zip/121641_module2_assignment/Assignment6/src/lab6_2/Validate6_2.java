package lab6_2;

public class Validate6_2 {
	public static void main(String[] args){
		try {
			Person person= new Person("Akshay",24);
			System.out.println("The age of the person is"+person.getName()+"\n"+"Age is "+person.getAge());
			
		} catch (AgeException e) {
			System.out.println("caught "+e);
		}
		
	}

}
