package lab6_2;

public class Person {
	private String name;
	private int age;
	public Person(String name, int age) throws AgeException {
		super();
		this.name = name;
		if (age<15){
			throw new AgeException(age);
		}
		else{
		this.age = age;
	}
	}
	public Person() {
		super();
	}
	public String getName() {
		return name;
	}
	public int getAge() {
		return age;
	}

}
