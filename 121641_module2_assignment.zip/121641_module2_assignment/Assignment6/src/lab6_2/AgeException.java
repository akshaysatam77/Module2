package lab6_2;

public class AgeException extends Exception {
	private int age;
	AgeException(int a){
		age=a;
		System.out.println("Age of the person should be more than 15");
	}
	
	public String toString() {
		return "Person [age=" + age + "]";
	}

}
