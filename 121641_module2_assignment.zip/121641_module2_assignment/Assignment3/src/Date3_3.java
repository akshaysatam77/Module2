
import java.time.LocalDate;
import java.time.Period;
import java.time.chrono.ChronoLocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.Scanner;

public class Date3_3 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the date in this format 'yyyy-MM-dd'");
		String date=sc.next();
		DateTimeFormatter formatter=DateTimeFormatter.ofPattern("yyyy-MM-dd");
				
		LocalDate date2=LocalDate.parse(date,formatter);
		LocalDate currentDate=LocalDate.now();
		Period period=date2.until(currentDate);
		System.out.println("Today"+currentDate);
		System.out.println("Days "+period.get(ChronoUnit.DAYS));
		System.out.println("Months "+period.get(ChronoUnit.MONTHS));
		System.out.println("Years "+period.get(ChronoUnit.YEARS));
/*
		System.out.println("Days "+period.getDays();
		System.out.println("Months "+period.getMonths());
		System.out.println("Years "+period.getYears());*/
	}
}



