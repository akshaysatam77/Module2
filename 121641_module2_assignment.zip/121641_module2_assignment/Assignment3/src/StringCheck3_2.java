import java.util.Scanner;


public class StringCheck3_2 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int c=0;
		System.out.println("Enter a string:");
		String string=sc.nextLine();
		for( int i=0;i<string.length()-1;i++)
		{
			int asc1=(int)string.charAt(i);
			int asc2=(int)string.charAt(i+1);
			if(asc1>asc2)
			{
				c++;
			}
		}
		if(c==0)
		{
			System.out.println("String is positive");
		}
		else
		{
			System.out.println("String is negative");
		}
	}

}
