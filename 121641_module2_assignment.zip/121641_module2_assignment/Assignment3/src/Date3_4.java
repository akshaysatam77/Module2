import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;


public class Date3_4 {

	public static void main(String[] args) {
	 Scanner sc=new Scanner(System.in);
	 System.out.println("Please enter 1st Date in this format'yyyy-MM-dd' :");
	 String date1=sc.nextLine();
	 System.out.println("Please enter 2nd Date in this format 'yyyy-MM-dd' :");
	 String date2=sc.nextLine();
	 
	 DateTimeFormatter formatter=DateTimeFormatter.ofPattern("yyyy-MM-dd");
	    LocalDate givenDate1=LocalDate.parse(date1,formatter);
		LocalDate givenDate2=LocalDate.parse(date2,formatter);
		LocalDate currentDate=LocalDate.now();
		Period period=givenDate1.until(givenDate2);
		System.out.println("Days "+period.getDays());
		System.out.println("Months "+period.getMonths());
		System.out.println("Years "+period.getYears());

	}

}
