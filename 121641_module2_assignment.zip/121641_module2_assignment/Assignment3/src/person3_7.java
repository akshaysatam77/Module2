import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;


public class person3_7 {
 public String firstName;
 public String lastName;
 public String dob;
public String getFirstName() {
	return firstName;
}
public void setFirstName(String firstName) {
	this.firstName = firstName;
}
public String getLastName() {
	return lastName;
}
public void setLastName(String lastName) {
	this.lastName = lastName;
}
public String getDob() {
	return dob;
}
public void setDob(String dob) {
	this.dob = dob;
}
  

public void calculateAge(String dob){
	
	DateTimeFormatter formatter=DateTimeFormatter.ofPattern("yyyy-MM-dd");
	
	LocalDate givenDate2=LocalDate.parse(dob,formatter);
	LocalDate currentDate=LocalDate.now();
	Period period=givenDate2.until(currentDate);
	System.out.println(getFullName());
	System.out.println("Age is");
	System.out.println("years"+period.getYears());
}
public String getFullName(){
	return (getFirstName()+" "+getLastName());
}

}
