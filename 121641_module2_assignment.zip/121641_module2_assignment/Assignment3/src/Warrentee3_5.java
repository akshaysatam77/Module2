import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;


public class Warrentee3_5 {
 public static void main(String[] args){
	 
	 Scanner sc=new Scanner(System.in);
	 System.out.println("Enter date in this format 'yyyy-MM-dd':");
	 String date=sc.nextLine();
	 DateTimeFormatter formatter= DateTimeFormatter.ofPattern("yyyy-MM-dd");
	 LocalDate date2=LocalDate.parse(date,formatter);
	 System.out.println("Enter warrentee period");
	 int warenteeMonths=sc.nextInt();
	 int warenteeYears=sc.nextInt();
	 
	 date2=date2.plusMonths(warenteeMonths);
	 System.out.println("warentee date is"+date2.plusYears(warenteeYears));
	 
	 
	 
 }
}
