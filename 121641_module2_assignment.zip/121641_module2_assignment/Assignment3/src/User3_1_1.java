
public class User3_1_1 {

	String result;

	public String addString(String string, int choice) {
	result=string+string;
	return result;
	}

	public String replaceOdd(String string, int choice) {
		StringBuilder sb=new StringBuilder(string);
		for(int i=0;i<sb.length();i++)
		{
			if(i%2!=0)
			{
				sb.replace(i, i+1,"#");
				
			}
			
		}
		result=new String(sb);
		return result;
	}

	public String removeDuplicate(String string, int choice) {
		 StringBuilder sb=new StringBuilder(string);
         for(int i=0;i<sb.length();i++){
	      for(int j=i+1;j<sb.length();j++)
	      {
	    	  if(sb.charAt(i)==sb.charAt(j)){
	    		  sb.delete(i,i+1);
	    		  break;
	    	  }
	       }
	      
	     }
	 
     result=new String(sb);
     return result;
     
	}

	public String changeOdd(String string, int choice) {
		 StringBuilder sb=new StringBuilder(string);
			for(int i=0;i<sb.length();i++){
				if(i%2!=0){
					char c= sb.charAt(i);
					sb.setCharAt(i, Character.toUpperCase(c));
				}
			}
	result=new String(sb);
    return result;
	}
}


