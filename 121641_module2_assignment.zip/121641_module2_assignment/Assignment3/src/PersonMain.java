import java.util.Scanner;


public class PersonMain {

	public static void main(String[] args) {
		person3_7 p1= new person3_7();
		 Scanner sc=new Scanner(System.in);
		 System.out.println(" enter birthate in this format'yyyy-MM-dd' :");
		 String dob=sc.next();
		 System.out.println("Enter name:");
		 String firstname=sc.next();
		 System.out.println("Enter last name:");
		 String lastname=sc.next();
		 p1.setLastName(lastname);
		  sc.close();
		  
		  p1.calculateAge(dob);
		  
		

	}

}
