import java.util.Scanner;


public class lab3_1 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		User3_1_1 user=new User3_1_1();
		System.out.println("Enter the string:");
		String string=sc.nextLine();
		System.out.println("1. Add the string to itself"+"\n"
		+"2. Replace odd position with #"+"\n"
		+"3. Remove duplicate characters"+"\n"
		+"4. Change odd characters to uppercase");
		System.out.println("Please Enter your choice:");
		int choice=sc.nextInt();
		switch(choice){
		case 1: user.addString(string,choice);
		break;
		case 2: user.replaceOdd(string,choice);
		break;
		case 3: user.removeDuplicate(string,choice);
		break;
		case 4: user.changeOdd(string,choice);
		break;
		default:
			System.out.println("Invalid choice");
		
		}
		System.out.println(user.result);

	}

}
