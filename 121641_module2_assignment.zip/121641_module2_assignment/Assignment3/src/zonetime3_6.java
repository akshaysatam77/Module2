import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Scanner;


public class zonetime3_6 {
  public static void main (String[] args){
	  Scanner sc=new Scanner(System.in);
	  System.out.println("Enter the zone id in given format 'Continent/City' :");
	  String zone=sc.next();
	  ZonedDateTime currentTime=ZonedDateTime.now(ZoneId.of(zone));
		System.out.println("Current Time in "+zone+" is "+currentTime);
  }
  
}
