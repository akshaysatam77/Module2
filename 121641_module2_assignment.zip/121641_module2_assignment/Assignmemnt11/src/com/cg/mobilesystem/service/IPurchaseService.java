package com.cg.mobilesystem.service;

import com.cg.mobiilesystem.dto.Purchase;
import com.cg.mobilesystem.exception.MobileException;

public interface IPurchaseService {
	
public boolean insetvalue(Purchase p)throws MobileException;
}

