
package com.cg.mobilesystem.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.cg.mobiilesystem.dto.Mobile;
import com.cg.mobiilesystem.dto.Purchase;
import com.cg.mobilesystem.exception.MobileException;
import com.cg.mobilesystem.util.JdbcUtil;

public class MobileDaoImpl implements ImobileDao {
	private static final Logger myLogger=Logger.getLogger(Purchase.class);
  Connection con;
  PreparedStatement pst;
	@Override
	public List<Mobile> showAll() throws MobileException{
		// TODO Auto-generated method stub
		con=JdbcUtil.getConnection();
		String query="SELECT * from mobiles";
		List<Mobile>mList=new ArrayList<Mobile>();
		
		try{
		
		pst=con.prepareStatement(query);
		ResultSet rs=pst.executeQuery();
		while(rs.next()){
			int m_id=rs.getInt(1);
			String m_name=rs.getString(2);
			double m_price=rs.getInt(3);
			int m_qty=rs.getInt(4);
			Mobile m=new Mobile();
			m.setMobileid(m_id);
			m.setName(m_name);
			m.setPrice(m_price);
			m.setQuantity(m_qty);
			mList.add(m);
			
			myLogger.info(" show all Successful");
			
		}
		
		}catch (SQLException e){
			myLogger.error("show all unsuccessful");
			e.printStackTrace();
		}finally{
			try{
				con.close();
			}catch (SQLException e){
				e.printStackTrace();
				throw new MobileException("data not found");
			}
		}
	
	return mList;
	
	}

	@Override
	public boolean deleteMobile(int mobileid)throws MobileException {
	  con=JdbcUtil.getConnection();
	  int rec=0;
	  String query="DELETE FROM MOBILES WHERE mobileid=?";
	  try {
		pst=con.prepareStatement(query);
		pst.setInt(1, mobileid);
		rec=pst.executeUpdate();
		if(rec>0)
			return true;
		myLogger.info("Delete Mobile Successful");
		
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		myLogger.error("Delete Mobile unsuccessful");
		e.printStackTrace();
	}finally{
		try{
			con.close();
		}catch (SQLException e){
			e.printStackTrace();
			throw new MobileException("Data not deleted");
		}
	  
		
	}	return false;
	}

	@Override
	public List<Mobile> searchByRange(int start, int end)throws MobileException {
		  con=JdbcUtil.getConnection();
		  
		  String query="SELECT * FROM MOBILES WHERE price >=? AND price<=?";
		  List<Mobile>mList=new ArrayList<Mobile>();
		  try {
			pst=con.prepareStatement(query);
			pst.setInt(1, start);
			pst.setInt(2, end);
			
			ResultSet rs=pst.executeQuery();
			while(rs.next()){
				int m_id=rs.getInt(1);
				String m_name=rs.getString(2);
				double m_price=rs.getInt(3);
				int m_qty=rs.getInt(4);
				Mobile m=new Mobile();
				m.setMobileid(m_id);
				m.setName(m_name);
				m.setPrice(m_price);
				m.setQuantity(m_qty);
				mList.add(m);
				
				myLogger.info("Mobile search Successful");
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			myLogger.error("Mobile Search unsuccessful");
			e.printStackTrace();
			throw new MobileException("data not found");
		}
		  
		return mList;
	}

	@Override
	public boolean updateQty(int mobileid, int qty) throws MobileException {
		// TODO Auto-generated method stub
		con=JdbcUtil.getConnection();
		int rec=0;
		String query="UPDATE MOBILES SET QUANTITY=QUANTITY-? WHERE MOBILEID=?";
		try {
			pst=con.prepareStatement(query);
			pst.setInt(1, qty);
			pst.setInt(2, mobileid);
			rec=pst.executeUpdate();
			if(rec>0)
				return true;
			myLogger.info("Mobile update Successful");
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			myLogger.error("Mobile update unsuccessful");
			e.printStackTrace();
		}finally{
			try{
				con.close();
			}catch (SQLException e){
				e.printStackTrace();
				throw new MobileException("data is not updated");
			}
		  
			
		return false;
	}
	}
}
