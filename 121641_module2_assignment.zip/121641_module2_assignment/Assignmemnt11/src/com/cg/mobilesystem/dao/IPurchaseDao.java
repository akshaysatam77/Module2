package com.cg.mobilesystem.dao;

import com.cg.mobiilesystem.dto.Purchase;
import com.cg.mobilesystem.exception.MobileException;

public interface IPurchaseDao {
	
	public boolean insert(Purchase P)throws MobileException;
	

}
