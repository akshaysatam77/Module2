package com.cg.mobilesystem.junittest;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cg.mobiilesystem.dto.Purchase;
import com.cg.mobilesystem.dao.IPurchaseDao;
import com.cg.mobilesystem.dao.PurchaseDaoImpl;
import com.cg.mobilesystem.exception.MobileException;

public class PurchaseInsertTest {
	IPurchaseDao inst;
	Purchase p;
	

	@Before
	public void setUp() throws Exception {
		inst=new PurchaseDaoImpl();
		p=new Purchase("Akshay","akshay@gmail.com","9876543210",1001,5);
		
	}

	@After
	public void tearDown() throws Exception {
		inst=null;
		p=null;
	}

	@Test
	public void testinsert() throws MobileException {
		assertTrue(inst.insert(p));
	}

}
