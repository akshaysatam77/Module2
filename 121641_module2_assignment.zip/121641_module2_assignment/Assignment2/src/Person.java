
public class Person {
	String firstName;
	String lastName;
	Gender gender;
	String phonenumber;
	public String getPhonenumber() {
		return phonenumber;
	}
	public void setPhonenumber(String phonenumber) {
		this.phonenumber = phonenumber;
	}
	
	
	
	public Person(String firstName, String lastName) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		
	}
	public Person() {
		super();
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public Gender getGender() {
		return gender;
	}
	public void setGender(Gender gender) {
		this.gender = gender;
	}
	void show()
	{
		
		 System.out.println("First name :"+getFirstName());
		 System.out.println("Last name :"+getLastName());
		 System.out.println("Gender :"+getGender());
		 System.out.println("Mobile no :"+getPhonenumber());

	}

}
