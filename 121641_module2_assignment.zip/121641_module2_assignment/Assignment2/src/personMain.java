import java.util.Scanner;
public class personMain {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String phonenumber;
     Person person=new Person("Akshay","Satam");
     Scanner sc=new Scanner(System.in);
     System.out.println("Enter phonenumber:");
     phonenumber=sc.nextLine();
     person.setPhonenumber(phonenumber);
     Gender gender=null;
     System.out.println("Enter Gender:");
     String m_gender=sc.nextLine();
     gender=Gender.valueOf(m_gender);
     person.setGender(gender);
     person.show();
     sc.close();
	}
}
