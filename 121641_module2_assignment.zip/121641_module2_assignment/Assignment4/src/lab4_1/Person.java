package lab4_1;

public class Person {
	private String name;
	private float age;
	public String getName() {
		return name;
	}
	
	public float getAge() {
		return age;
	}
	
	public Person(String name, float age) {
		super();
		this.name = name;
		this.age = age;
	}
	@Override
	public String toString() {
		return "Person [name=" + name + ", age=" + age + "]";
	}

}
