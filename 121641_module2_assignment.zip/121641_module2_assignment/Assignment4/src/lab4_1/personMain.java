package lab4_1;

public class personMain {
 public static void main(String[] args){
	 Person smith= new Person("Smith",23);
	 Person kathy= new Person("Kathy",25);
	 
	 Account smithAccount = new Account(1,2000);
	 smithAccount.setAccHolder(smith);
	 System.out.println(smithAccount);
	 
	 Account kathyAccount = new Account(2,3000);
	 kathyAccount.setAccHolder(kathy);
	 System.out.println(kathyAccount);
	 
	 
	 smithAccount.deposite(2000);
	 kathyAccount.withdraw(2000);
	 System.out.println("Updated Balance of Smith "+smithAccount.getBalance());
	 System.out.println("Updated Balance of Kathy "+kathyAccount.getBalance());
 }
 
}
