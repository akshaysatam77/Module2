package lab4_1;

public class Account {
	private long accNum;
	private double balance;
	private Person accHolder;
	public long getAccNum() {
		return accNum;
	}
	public void setAccNum(long accNum) {
		this.accNum = accNum;
	}
	
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public Person getAccHolder() {
		return accHolder;
	}
	public void setAccHolder(Person accHolder) {
		this.accHolder = accHolder;
	}
	public Account(long accNum, double balance) {
		super();
		this.accNum = accNum;
		this.balance = balance;
	}
	public Account() {
		super();
	}
  public void deposite(double x){
	  balance=balance+x;
	  
   }
  public void withdraw(double x){
	  balance=balance-x;
	  
  }
  public double getBalance(){
     return balance; 
  
  }
@Override
public String toString() {
	return "Account [accNum=" + accNum + ", balance=" + balance
			+ ", accHolder=" + accHolder + "]";
}

}
