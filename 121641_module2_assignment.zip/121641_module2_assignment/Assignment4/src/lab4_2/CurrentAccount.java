package lab4_2;

public class CurrentAccount extends Account {
	public double x=0;
    public double Balance=10000;
    public double overDraftLimit=10000;
	public boolean withDraw(double amount){
	 	x=amount-Balance;
	 	if(x>=overDraftLimit){
	 		if(x<0){
	 			x=-x;
	 		}
	 		return true;
	 	}
	 	else return false;
	}

}
