package lab4_2;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     SavingAccount sa=new SavingAccount();
     CurrentAccount ca=new CurrentAccount();
     sa.withDraw(800);
     if(ca.withDraw(9000)){
    	 System.out.println("Successful");
     }
     else{
    	 System.out.println("unsuccessful");
    	 
     }
     
	}

}
