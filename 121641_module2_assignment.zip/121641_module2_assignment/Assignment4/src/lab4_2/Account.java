package lab4_2;

public class Account {
   public void withDraw(){
	   

	}
	

}
