package lab4_2;

public class SavingAccount extends Account {
	
public double Balance=2000;
public final double MinBalance=500;	
public void withDraw(double Amount)	{

	Balance=Balance-Amount;
	if(Balance<=MinBalance){
		System.out.println("Cannot withdraw");
		
	}
		
	else{
		System.out.println("Balance="+Balance);
	}
}
	

}
