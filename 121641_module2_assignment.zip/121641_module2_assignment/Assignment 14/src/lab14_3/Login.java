package Lab14_3;

@FunctionalInterface
public interface Login {
	public boolean validate(String username,String password);

}
