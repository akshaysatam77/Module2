package com.cg.eis.service;

public interface Employee_Service {
  public void inputEmployee();
  public void findInsuranceScheme();
  public void displayDetails();
  
}
