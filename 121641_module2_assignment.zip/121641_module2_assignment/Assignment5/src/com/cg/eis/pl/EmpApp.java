package com.cg.eis.pl;

import com.cg.eis.service.Employee_ServiceImp1;

public class EmpApp {
	public static void main(String[] args){
		Employee_ServiceImp1 emp=new Employee_ServiceImp1();
	    emp.inputEmployee();
		emp.findInsuranceScheme();emp.displayDetails();
		
	}

}
