
public class AccountImp15_3 extends Account5_3 {
	 
	public AccountImp15_3(double balance) {
		super(balance);
	
	}


		@Override
		public void withDraw(double x){
				setBalance(getBalance()-x);
		}
		
	}


