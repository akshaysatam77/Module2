
public class PersonMain5_3 {
	public static void main(String[] args) {
		Person5_3 smith=new Person5_3("Smith",23);
		Person5_3 kathy=new Person5_3("Kathy",25);
		
		
	    Account5_3 smithAccount5_3=new  AccountImp15_3(5000);
		smithAccount5_3.setAccHolder(smith);
		System.out.println(smithAccount5_3);
		
		Account5_3 kathyAccount5_3=new AccountImp15_3(2000);
		kathyAccount5_3.setAccHolder(kathy);
		System.out.println(kathyAccount5_3);
		
		smithAccount5_3.deposit(2000);
		kathyAccount5_3.withDraw(1000);
		
		
		System.out.println("Deposited successfully. Smith's Balance is "+smithAccount5_3.getBalance());
		System.out.println("Cash withdrawn successfully. Balance is "+kathyAccount5_3.getBalance());

	}

}


