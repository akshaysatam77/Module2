package com.cg.mobilesystem.ui;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;













import com.cg.mobiilesystem.dto.Purchase;
import com.cg.mobilesystem.exception.MobileException;
import com.cg.mobilesystem.service.IMobileService;
import com.cg.mobilesystem.service.IMobileServiceImpl;
import com.cg.mobilesystem.service.IPurchaseService;
import com.cg.mobilesystem.service.PurchaseServiceImpl;

public class MobileApp {
	private static final Logger myLogger=Logger.getLogger(Purchase.class);
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		IMobileService empService=new IMobileServiceImpl();
		IPurchaseService purservice=new PurchaseServiceImpl();
		int choice=0;
		int qty;
		do{
			printDetail();
		Scanner scr=new Scanner(System.in);
		System.out.println("Enter Choice: ");
		choice=scr.nextInt();
		switch(choice){
		case 1://showAll
		{
			
			try {
				System.out.println(empService.showAll());
				myLogger.info("data found");
	
			} catch (MobileException e1) {
				// TODO Auto-generated catch block
				//e1.printStackTrace();--Developer
			   myLogger.error("data not found");
			     e1.printStackTrace();
			 	
			}	
			break;
		}
	    case 2://Purchase Mobile by range
			
			try {
				Scanner sc=new Scanner(System.in);
				System.out.println("Enter start price: ");
				int price1=sc.nextInt();
				System.out.println("Enter end price: ");
				int price2=sc.nextInt();
				System.out.println(empService.searchByRange(price1, price2));
				myLogger.info("data found");
				
			} catch (MobileException e) {
				// TODO Auto-generated catch block
				 myLogger.error("data not found");
				e.printStackTrace();
			}
		
			break;
			
			
		  case 3: //purchase mobile 
			  Scanner sc=new Scanner(System.in);
			  Purchase p=new Purchase();
			  int count=0;
					System.out.println("Enter name : ");
					String name=sc.next();
					Pattern cname= Pattern.compile("^[A-Z]{1}[a-zA-Z]{0,19}$");
					Matcher name1= cname.matcher(name);
					if(name1.matches()){
						p.setCname(name);
						count++;
					}
					

					System.out.println("Enter email id :");
					String email=sc.next();
					Pattern mailid=Pattern.compile("^[a-zA-Z0-9_-]+@[a-z]+.[a-z]+$");
					Matcher mail1= mailid.matcher(email);
					if(mail1.matches()){
						p.setMailid(email);
						count++;
						
					}
					
					
					System.out.println("Enter phone number :");
					String phoneno=sc.next();
					Pattern phonenumber=Pattern.compile("^[7|8|9]{1}[0-9]{9}$");
					Matcher phone1=phonenumber.matcher(phoneno);
					if(phone1.matches()){
						p.setPhonenumber(phoneno);
						count++;
					}
					
					
					System.out.println("Enter Mobile id:");
					int mid=sc.nextInt();
					Pattern mobileid=Pattern.compile("^[0-9]{4}$");
					Matcher mobileid1 = mobileid.matcher(String.valueOf(mid));
					
					if(mobileid1.matches()){
						p.setMobileid(mid);
						count++;
					}
				
					
					System.out.println("Enter the quantity");
					qty=sc.nextInt();
					if(qty>0 && qty <= empService.checkAvailableMobiles(mid)){
						p.setQuantity(qty);
					}else{
						System.out.println("Enter Correct quantity");
					}
					
					
				  if(count==4){
					  
				    boolean var;
				    try{
				    var=purservice.insetvalue(p);
				    System.out.println(var);
				    
				    }catch(MobileException e){
				    	e.printStackTrace();
				    }
				   
				    	
				    
				  }else{
					  
					  System.out.println("Enter purchase detail again");
				  }
				  break;
			
		case 4://Delete
			
			try{
			//Scanner sc=new Scanner(System.in);
			System.out.println("Enter Mobile Id:");
			int id=scr.nextInt();
			empService.deleteMobile(id)	;
			myLogger.info("data found");
			}catch (MobileException e) {
				// TODO Auto-generated catch block
				 myLogger.error("data not found");
				e.printStackTrace();
			}
			
			break;
		case 5://update
		
	
		
			try{
				//Scanner sc=new Scanner(System.in);
			    System.out.println("Enter Mobile Id:");
				int id=scr.nextInt();
				System.out.println("Enter Quantity: ");
				int quantity=scr.nextInt();
				empService.UpdateQty(id,quantity);
				myLogger.info("data found");
				System.out.println("Quantity Updated");
			}catch (MobileException e) {
				// TODO Auto-generated catch block
				 myLogger.error("data not found");
				e.printStackTrace();
			}
			
			
			break;
			
		case 6: //Exit
		
			break;
			
			
		}
			
			
		}
		while(choice<6);
		

	}
	
	public static void printDetail(){
		System.out.println("**********");
		System.out.println("1. Show Mobile ");
		System.out.println("2. Purchase Mobile by range");
		System.out.println("3. Purchase Mobile");
		System.out.println("4. Delete Mobile data from stack");
		System.out.println("5. Update quantity of Mobile");
		System.out.println("6. Exit");
		System.out.println("***********");
	}



}
