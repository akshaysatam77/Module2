package com.cg.mobilesystem.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.cg.mobiilesystem.dto.Purchase;
import com.cg.mobilesystem.exception.MobileException;
import com.cg.mobilesystem.util.JdbcUtil;

public class PurchaseDaoImpl implements IPurchaseDao {
	private static final Logger myLogger=Logger.getLogger(Purchase.class);
	Connection con;
	PreparedStatement pst;
	ImobileDao upd= new  MobileDaoImpl();

	@Override
	public boolean insert(Purchase p) {
		// TODO Auto-generated method stub
		int rec=0;
	
		
		String query="Insert into purchasedetails values(sequence_id.NEXTVAL,?,?,?,sysdate,?)";
		
		try {
			con = JdbcUtil.getConnection();
			pst=con.prepareStatement(query);
			pst.setString(1,p.getCname());
			pst.setString(2,p.getMailid());
			pst.setString(3,p.getPhonenumber());
			pst.setInt(4, p.getMobileid());
			rec=pst.executeUpdate();
			if(rec>0)
			{
				upd.updateQty(p.getMobileid(), p.getQuantity());
				return true;
			}
		myLogger.info("Data inserted successfully");
		
		
		
		} catch (MobileException e1) {
			// TODO Auto-generated catch block
			myLogger.error("data not inserted");
			e1.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	return false;
	}

	//private void updateQty(int mobileid, int qty) {
		// TODO Auto-generated method stub
		
	}


