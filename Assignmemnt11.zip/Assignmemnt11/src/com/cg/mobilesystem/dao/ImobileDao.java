package com.cg.mobilesystem.dao;

import java.util.List;

import com.cg.mobiilesystem.dto.Mobile;
import com.cg.mobilesystem.exception.MobileException;


public interface ImobileDao {
	 List<Mobile> showAll() throws MobileException;
	  boolean deleteMobile(int mobileid) throws MobileException;
	  List<Mobile>searchByRange(int start, int end) throws MobileException;
	  boolean updateQty(int mobileid,int qty)throws MobileException;
	  int checkAvailableMobiles(int mobileid);
	  
 
  
  
}
