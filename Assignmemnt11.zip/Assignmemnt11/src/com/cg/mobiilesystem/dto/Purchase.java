package com.cg.mobiilesystem.dto;

import java.util.Date;

public class Purchase {
private int purchaseid;
private String cname;
private String mailid;
private String phonenumber;

private int quantity;
private int mobileid;
public Purchase() {
	super();
}
public Purchase( String cname, String mailid,String phonenumber, int mobileid,int quantity) {
	super();
	
	this.cname = cname;
	this.mailid = mailid;
	this.phonenumber = phonenumber;
	
	this.quantity = quantity;
	this.mobileid = mobileid;
}

public String getCname() {
	return cname;
}
public void setCname(String cname) {
	this.cname = cname;
}
public String getMailid() {
	return mailid;
}
public void setMailid(String mailid) {
	this.mailid = mailid;
}
public String getPhonenumber() {
	return phonenumber;
}
public void setPhonenumber(String phonenumber) {
	this.phonenumber = phonenumber;
}
public int getQuantity() {
	return quantity;
}
public void setQuantity(int quantity) {
	this.quantity = quantity;
}
public int getMobileid() {
	return mobileid;
}
public void setMobileid(int mobileid) {
	this.mobileid = mobileid;
}
@Override
public String toString() {
	return "Purchase [purchaseid=" + purchaseid + ", cname=" + cname
			+ ", mailid=" + mailid + ", phonenumber=" + phonenumber
			+  ", quantity=" + quantity
			+ ", mobileid=" + mobileid + "]";
}




}